function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  let value = 0;
  fill(value);
  rect(25, 25, 50, 50);
  describe('black 50-by-50 rect turns white with mouse click/press.');
   
     background(204);
  line (20, 20, 220, 100);
  if (keyIsPressed) {
  line(220, 20, 20, 100);
  }
}

function draw() {
  background(204);
  strokeWeight(50);
  line (20, 20, 220, 100);
  if (keyIsPressed) {
  line(220, 20, 20, 100);
     for (let i = 10; i < width; i += 10) {
    if (i % 20 === 0) {
      stroke(255);
      line(i, 80, i, height / 2);
    } else {
      stroke(153);
      line(i, 20, i, 180);
    }
  }
}
 }
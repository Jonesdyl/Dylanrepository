function setup() {
  createCanvas(400, 400);
}
function draw() {
  background(300);
 rect(10,10,200,200,30)
  fill(50,20,50)

  ellipseMode(RADIUS);
fill(255);
ellipse(50, 50, 30, 30);
ellipseMode(CENTER);
fill(200,50,100);
ellipse(50, 50, 30, 30);
  
  rect(110, 20, 55, 55, 20);
   fill(300,100,0) 
  {
  if (keyIsPressed === true) {
    fill(100);
  } else {
    fill(260,100,350);
  }
  rect(20, 90, 70, 70);
    fill(255,90,80)
    
let value = 0;
  fill(value);
  rect(100, 85, 50, 50);
  describe('hsl(289,91%,43%) 50-by-50 rect turns white with mouse click/press.');
  }}

function setup() {
  createCanvas(windowWidth, windowHeight);
}

function draw() {
  background(0);
  translate(width / 2, height / 2);
  
  noStroke();
  fill(150, 0, 100,120);
  beginShape();
  for (let a = 0; a < TWO_PI; a += 0.1) {
    const r = 5;
    const x = r * 16 * pow(sin(a), 3);
    const y = -r * (13 * cos(a) - 5 * cos(2 * a) - 2 * cos(3 * a) - cos(4 * a));

    vertex(x, y);
  }
  endShape();
  quad(50, 50, 80, 30, 80, 70, 20, 70);
  quad(50, 50, 80, 10, 80, 70, 20, 70);
  
  square(100, 20, 55);
  square(30, 80, 60);
  square(155, 45, 60);
  square(-155, 20, 95);


}